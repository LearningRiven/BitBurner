//Main idea taken from - https://gist.github.com/smolgumball/14559c7597187ad786339f75ea35d7de
//Credit - smolgumball

import Main from "/vue/classes/main.js"

/** @param {NS} ns **/
export function main(ns) {
    const main = new Main(ns)
    main.init()
}