export default class ScssCompiler {

    initScss(win, doc) {
        if (typeof win !== 'undefined' && typeof doc !== 'undefined') {
            if (typeof Sass === 'undefined' || typeof Sass.compile !== 'function') {
                var sassJSScript = doc.createElement('script');
                sassJSScript.type = 'text/javascript';
                sassJSScript.src = 'https://cdn.jsdelivr.net/npm/sass.js@0.11.1/dist/sass.sync.js';
                sassJSScript.onload = findAndConvertTags;
    
                // Monkey patch `window.define` to ensure sass installs properly
                win._defineBak = win.define
                win.define = undefined
                doc.head.appendChild(sassJSScript);
            } else {
                findAndConvertTags(win, doc);
            }
    
            if (typeof win !== 'undefined' && win !== null && typeof Sass !== 'undefined' && typeof Sass.compile === 'function') {
                setTimeout(findAndConvertTags, 0);
            }
        }
    }

    findAndConvertTags() {
        // Restore `window.define`
        win.define = win._defineBak
        var sassTags = doc.getElementsByTagName('style');
        for (var i = sassTags.length - 1; i >= 0; i--) {
            if (sassTags[i].type.toLowerCase() === 'text/scss' && sassTags[i]._scssCompiled !== true) {
                Sass.compile(sassTags[i].innerHTML, function (compiledCSS) {
                    var rawStyle = doc.createElement('style');
                    rawStyle.type = 'text/css';
                    rawStyle.innerHTML = compiledCSS.text;
                    doc.getElementById(`${vueAppId}-wrap`).appendChild(rawStyle);
                });
                sassTags[i]._scssCompiled = true
            }
        }
    }
    
}