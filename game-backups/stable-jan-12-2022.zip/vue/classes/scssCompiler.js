export default class ScssCompiler {

    initScss(win, doc) {
        function findAndConvertTags() {
            _window.define = _window._defineBak
            var sassTags = _document.getElementsByTagName('style');
            for (var i = sassTags.length - 1; i >= 0; i--) {
                if (sassTags[i].type.toLowerCase() === 'text/scss' && sassTags[i]._scssCompiled !== true) {
                    Sass.compile(sassTags[i].innerHTML, function (compiledCSS) {
                        var rawStyle = _document.createElement('style');
                        rawStyle.type = 'text/css';
                        rawStyle.innerHTML = compiledCSS.text;
                        _document.getElementById(`${vueAppId}-wrap`).appendChild(rawStyle);
                    });
                    sassTags[i]._scssCompiled = true
                }
            }
        }
        if (typeof _window !== 'undefined' && typeof _document !== 'undefined') {
            if (typeof Sass === 'undefined' || typeof Sass.compile !== 'function') {
                var sassJSScript = _document.createElement('script');
                sassJSScript.type = 'text/javascript';
                sassJSScript.src = 'https://cdn.jsdelivr.net/npm/sass.js@0.11.1/dist/sass.sync.js';
                sassJSScript.onload = findAndConvertTags();
    
                // Monkey patch `window.define` to ensure sass installs properly
                _window._defineBak = _window.define
                _window.define = undefined
                _document.head.appendChild(sassJSScript);
            } else {
                findAndConvertTags();
            }
    
            if (typeof _window !== 'undefined' && _window !== null && typeof Sass !== 'undefined' && typeof Sass.compile === 'function') {
                setTimeout(findAndConvertTags, 0);
            }
        }
    }
    
}