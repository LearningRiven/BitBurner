export function calculateAvailablePorts(ns){
	var ports = [];
	if(ns.fileExists("BruteSSH.exe", "home")){
		ports.push("BruteSSH.exe");
	}
	if(ns.fileExists("FTPCrack.exe", "home")){
		ports.push("FTPCrack.exe");
	}
	return ports;
}

export function calculateThreads(ns, scriptRam, server, modifier){
	var max = server.maxRam;
	var cur = server.ramUsed;

	var threads = (max - cur) / scriptRam;
	threads = Math.floor(threads/modifier);
	
	return threads;
}